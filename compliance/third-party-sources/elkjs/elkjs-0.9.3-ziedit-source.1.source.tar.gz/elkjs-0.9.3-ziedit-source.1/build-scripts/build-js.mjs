import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
const source = path.resolve('elkjs');
function cli(relative, args) {
  const result = spawnSync(process.execPath, [path.join(source, relative), ...args], { cwd: source, stdio: 'inherit' });
  if (result.error || result.status !== 0) throw new Error(`Build CLI failed ${relative}: ${result.error ?? result.status}`);
}
for (const filename of ['elk-worker.js', 'elk-worker.min.js']) if (!fs.existsSync(path.join(source, 'build/js', filename))) throw new Error(`Missing newly compiled GWT output: ${filename}`);
cli('node_modules/babel-cli/bin/babel.js', ['src/js/', '-d', 'build/js/']);
fs.mkdirSync(path.join(source, 'lib'), { recursive: true });
cli('node_modules/browserify/bin/cmd.js', ['build/js/main-api.js', '-s', 'ELK', '--outfile', 'lib/elk-api.js']);
cli('node_modules/browserify/bin/cmd.js', ['build/js/main-node.js', '-s', 'ELK', '--outfile', 'lib/elk.bundled.js']);
for (const filename of ['elk-worker.js', 'elk-worker.min.js']) fs.copyFileSync(path.join(source, 'build/js', filename), path.join(source, 'lib', filename));
fs.copyFileSync(path.join(source, 'build/js/main-node.js'), path.join(source, 'lib/main.js'));
for (const filename of fs.readdirSync(path.join(source, 'typings'))) if (filename.endsWith('.d.ts')) fs.copyFileSync(path.join(source, 'typings', filename), path.join(source, 'lib', filename));
const outputs = fs.readdirSync(path.join(source, 'lib')).sort().map(filename => {
  const bytes = fs.readFileSync(path.join(source, 'lib', filename));
  return { path: filename, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') };
});
fs.writeFileSync('rebuilt-js-inventory.json', JSON.stringify(outputs, null, 2) + '\n');
console.log(JSON.stringify(outputs, null, 2));
