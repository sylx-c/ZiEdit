import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const root = path.resolve('E:/Project/ZiEdit');
const ReferenceELK = require(path.join(root, 'node_modules/elkjs/lib/elk.bundled.js'));
const candidatePath = process.argv[2] ? path.resolve(process.argv[2]) : null;
const CandidateELK = candidatePath ? require(candidatePath) : null;
const options = { 'elk.algorithm': 'layered', 'elk.randomSeed': 42 };
const node = (id, extra = {}) => ({ id, width: 80, height: 40, ...extra });
const edge = (id, source, target) => ({ id, sources: [source], targets: [target] });
const cases = [
  { name: 'layered chain down', graph: { id: 'root', layoutOptions: options, children: [node('a'), node('b'), node('c')], edges: [edge('ab', 'a', 'b'), edge('bc', 'b', 'c')] } },
  { name: 'layered cycle and parallel edges', graph: { id: 'root', layoutOptions: { ...options, 'elk.direction': 'RIGHT' }, children: [node('a'), node('b'), node('c')], edges: [edge('ab1', 'a', 'b'), edge('ab2', 'a', 'b'), edge('bc', 'b', 'c'), edge('ca', 'c', 'a')] } },
  { name: 'compound with cross-boundary edges', graph: { id: 'root', layoutOptions: { ...options, 'elk.hierarchyHandling': 'INCLUDE_CHILDREN' }, children: [node('group', { children: [node('a'), node('b')], edges: [edge('ab', 'a', 'b')] }), node('c')], edges: [edge('ac', 'a', 'c')] } },
  { name: 'fixed sided ports', graph: { id: 'root', layoutOptions: options, children: [node('a', { layoutOptions: { 'elk.portConstraints': 'FIXED_SIDE' }, ports: [{ id: 'out', width: 8, height: 8, layoutOptions: { 'elk.port.side': 'EAST' } }] }), node('b', { ports: [{ id: 'in', width: 8, height: 8, layoutOptions: { 'elk.port.side': 'WEST' } }] })], edges: [edge('ab', 'out', 'in')] } },
  { name: 'disconnected graph', graph: { id: 'root', layoutOptions: options, children: [node('a'), node('b'), node('c'), node('d')], edges: [edge('ab', 'a', 'b'), edge('cd', 'c', 'd')] } },
  { name: 'labels and edge labels', graph: { id: 'root', layoutOptions: options, children: [node('a', { labels: [{ text: 'Alpha', width: 40, height: 14 }] }), node('b')], edges: [{ ...edge('ab', 'a', 'b'), labels: [{ text: 'route', width: 35, height: 14 }] }] } },
];
for (const algorithm of ['force', 'mrtree', 'rectpacking', 'radial', 'disco', 'sporeOverlap', 'sporeCompaction']) cases.push({ name: `algorithm ${algorithm}`, graph: { id: 'root', layoutOptions: { ...options, 'elk.algorithm': algorithm }, children: [node('a', { x: 0, y: 0 }), node('b', { x: 10, y: 10 }), node('c', { x: 80, y: 10 })], edges: algorithm === 'rectpacking' ? [] : [edge('ab', 'a', 'b'), edge('bc', 'b', 'c')] } });
const reference = new ReferenceELK();
const candidate = CandidateELK ? new CandidateELK() : null;
const report = { reference: 'elkjs@0.9.3 original verified npm package', candidate: candidatePath, algorithms: {}, options: {}, cases: [] };
try {
  const ra = (await reference.knownLayoutAlgorithms()).map(a => a.id).sort();
  report.algorithms.reference = ra;
  const ro = (await reference.knownLayoutOptions()).map(o => o.id).sort();
  report.options.referenceCount = ro.length;
  if (candidate) {
    const ca = (await candidate.knownLayoutAlgorithms()).map(a => a.id).sort();
    const co = (await candidate.knownLayoutOptions()).map(o => o.id).sort();
    report.algorithms.candidate = ca;
    report.algorithms.equal = JSON.stringify(ra) === JSON.stringify(ca);
    report.options.candidateCount = co.length;
    report.options.equal = JSON.stringify(ro) === JSON.stringify(co);
  }
  for (const fixture of cases) {
    const result = { name: fixture.name };
    let original;
    try { original = await reference.layout(structuredClone(fixture.graph)); result.referenceAccepted = true; }
    catch (error) { result.referenceAccepted = false; result.referenceError = error.message; }
    if (candidate) {
      try {
        const rebuilt = await candidate.layout(structuredClone(fixture.graph));
        result.candidateAccepted = true;
        result.exactOutputMatch = JSON.stringify(original) === JSON.stringify(rebuilt);
        const checkFinite = value => { if (Array.isArray(value)) value.forEach(checkFinite); else if (value && typeof value === 'object') for (const [key, item] of Object.entries(value)) { if (['x','y','width','height'].includes(key) && typeof item === 'number' && !Number.isFinite(item)) throw Error(`Nonfinite ${key}`); checkFinite(item); } };
        checkFinite(rebuilt);
      } catch (error) { result.candidateAccepted = false; result.candidateError = error.message; }
    }
    report.cases.push(result);
  }
} finally {
  for (const [name, engine] of [['reference', reference], ['candidate', candidate]]) {
    if (!engine) continue;
    try { engine.terminateWorker(); }
    catch (error) { report[`${name}ShutdownError`] = error.message; }
  }
}
const output = path.join(root, 'docs/tmp/corresponding-source-build', candidate ? 'layout-comparison.json' : 'reference-layout-behavior.json');
fs.writeFileSync(output, JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
if (candidate && (!report.algorithms.equal || !report.options.equal || report.cases.some(c => c.referenceAccepted !== c.candidateAccepted || (c.referenceAccepted && !c.exactOutputMatch)))) process.exitCode = 1;
